author '.xcyber (discord)'
description 'Simple Car Washing'
lua54 'yes'
games {'gta5'}
fx_version 'adamant'

shared_scripts {
  '@es_extended/imports.lua',
  '@ox_lib/init.lua',
  'shared/*.lua'
}

client_script {
  'shared/*.lua',
  'client/*.lua',
}

server_script {
  'shared/*.lua',
  'server/*.lua',
}

escrow_ignore {
  'shared/*.lua'
}
dependency '/assetpacks'